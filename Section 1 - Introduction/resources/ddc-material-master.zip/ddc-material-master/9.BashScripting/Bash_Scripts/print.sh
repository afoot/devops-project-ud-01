#!/bin/bash

echo "Welcome to bash scripting."

echo

echo "This is our first script."
