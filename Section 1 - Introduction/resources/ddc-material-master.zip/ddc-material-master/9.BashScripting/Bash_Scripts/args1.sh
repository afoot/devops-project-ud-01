#!/bin/bash

echo "Printing script name"
echo $0
echo

echo "printing first argument"
echo $1

echo
echo "printing second argument"
echo $2

echo $9
echo $10
