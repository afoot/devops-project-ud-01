x=2

print("Learning Indentation")
print()

if x == 0:
  print("In the If Block.")
  print("Value of x is 0")
else:
  print("In the else block.")
  print("Value of x is non zero")
  print()
  print("This statement is out of if/else block.")